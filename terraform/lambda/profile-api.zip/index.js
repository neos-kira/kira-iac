const AWS = require('aws-sdk')
const doc = new AWS.DynamoDB.DocumentClient()

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json',
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: CORS,
    body: JSON.stringify(body),
  }
}

exports.handler = async (event) => {
  const method = event.requestContext?.http?.method || event.httpMethod || 'GET'
  const username = event.queryStringParameters?.username

  if (method === 'OPTIONS') {
    return { statusCode: 204, headers: { ...CORS, 'Access-Control-Allow-Methods': 'GET, PUT, OPTIONS' }, body: '' }
  }

  const TableName = process.env.TABLE_NAME || ''
  if (!TableName) return json(500, { error: 'TABLE_NAME not set' })

  if (method === 'GET') {
    if (!username) return json(400, { error: 'username required' })
    try {
      const { Item } = await doc.get({ TableName, Key: { username: String(username) } }).promise()
      if (!Item) return json(200, {})
      return json(200, { username: Item.username, lastName: Item.lastName ?? '', firstName: Item.firstName ?? '' })
    } catch (e) {
      console.error(e)
      return json(500, { error: 'failed to get profile' })
    }
  }

  if (method === 'PUT') {
    let body
    try {
      body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body
    } catch {
      return json(400, { error: 'invalid JSON' })
    }
    const un = body?.username
    const lastName = body?.lastName ?? ''
    const firstName = body?.firstName ?? ''
    if (!un || typeof lastName !== 'string' || typeof firstName !== 'string') {
      return json(400, { error: 'username, lastName, firstName required' })
    }
    try {
      await doc.put({ TableName, Item: { username: String(un), lastName, firstName } }).promise()
      return json(200, { username: un, lastName, firstName })
    } catch (e) {
      console.error(e)
      return json(500, { error: 'failed to save profile' })
    }
  }

  return json(405, { error: 'method not allowed' })
}
